// Create.js

import React, { Component } from 'react';
import axios from 'axios';

export default class RegisterUser extends Component {

    constructor(props) {
        super(props);
        this.onChangeHostemail = this.onChangeHostemail.bind(this);
        this.onChangepassword = this.onChangepassword.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            email: '',
            password: '',
            last_name: '',
            first_name: '',
            gender: '',
        }
    }
    onChangeHostemail(e) {
        this.setState({
            email: e.target.value
        });
    }
    onChangepassword(e) {
        this.setState({
            password: e.target.value
        });
    }
    onChangeHostGender(e) {
        this.setState({
            gender: e.target.value
        });
    }
    onChangeFname(e) {
        this.setState({
            first_name: e.target.value
        });
    }
    onChangeLname(e) {
        this.setState({
            last_name: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();
        const serverport = {
            email: this.state.email,
            password: this.state.password
        }
        axios.post('http://192.168.6.234:3000/signup', serverport)
            .then(res => console.log(res.data));

        this.setState({
            email: '',
            password: ''
        });
    }

    render() {
        return (
            <div style={{ marginTop: 50 }}>
                <h3>Add New Server</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>First Name:  </label>
                        <input type="text" className="form-control" onChange={this.onChangeFname} placeholder="Please enter first name" value={this.state.fname} />
                    </div>
                    <div className="form-group">
                        <label>Last Name:  </label>
                        <input type="text" className="form-control" onChange={this.onChangeLname} placeholder="Please enter last name" value={this.state.lname} />
                    </div>
                    <div className="form-group">
                        <label>Gender: </label>
                        <select onChange={this.onChangeHostGender} className="form-control" value={this.state.gender}>
                            <option value="">---Please select the gender---</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Email:  </label>
                        <input type="text" className="form-control" onChange={this.onChangeHostemail} placeholder="Please enter Email" value={this.state.email} />
                    </div>
                    <div className="form-group">
                        <label>Password: </label>
                        <input type="password" className="form-control" onChange={this.onChangepassword} placeholder="Please enter password" value={this.state.pass} />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Register" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}