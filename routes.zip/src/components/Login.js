// Create.js

import React, { Component } from 'react';
import axios from 'axios';

export default class Login extends Component {

    constructor(props) {
        super(props);
        this.onChangeHostemail = this.onChangeHostemail.bind(this);
        this.onChangepassword = this.onChangepassword.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            email: '',
            password: ''
        }
    }
    onChangeHostemail(e) {
        this.setState({
            email: e.target.value
        });
    }
    onChangepassword(e) {
        this.setState({
            password: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();
        const serverport = {
            email: this.state.email,
            password: this.state.password
        }
        axios.post('http://192.168.6.234:3000/login', serverport)
        .then(res => console.log(res.data));
        
        this.setState({
            email: '',
            password: ''
        });
    }

    render() {
        return (
            <div style={{marginTop: 50}}>
                <h3>Add New Server</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Add Host email:  </label>
                        <input type="text" className="form-control" onChange={this.onChangeHostemail}/>
                    </div>
                    <div className="form-group">
                        <label>Add Server password: </label>
                        <input type="text" className="form-control" onChange={this.onChangepassword}/>
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Add Node server" className="btn btn-primary"/>
                    </div>
                </form>
            </div>
        )
    }
}